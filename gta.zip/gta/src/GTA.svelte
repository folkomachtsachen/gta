<script>

    import { status } from './components/stores/Status.js';    
    import Main from './components/_main/Main.svelte';
    import Login from './components/_main/Login.svelte';
    import Backdrop from './components/modal/Backdrop.svelte';
    import TextEditor from './components/modal/TextEditor.svelte';

    //  --------------------------------------------------
    // 
    //  Reactivity, the Svelte way
    //  
    //  State values can be stored in "stores", e.g. "status".
    //  In the component, we reference a state value, e.g. "$: dialog = $status.dialog;"
    //  Now we can change the org store value at any place within the app
    //  and this component will react (renders again with new values):

    $: showBackdrop = $status.dialog !== "none";
    $: dialog = $status.dialog;

    //  --------------------------------------------------

</script>


<main>
    
    {#if $status.loggedin}
        <Main></Main>
    {:else}
        <Login></Login>
    {/if}
    
    {#if showBackdrop}
        <Backdrop></Backdrop>
    {/if}

</main>

{#if dialog === "editor"}
    <TextEditor></TextEditor>
{/if}

