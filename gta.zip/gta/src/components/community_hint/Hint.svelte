<script>

    import { users } from '../stores/Users.js';
    import { status } from '../stores/Status.js';   

    $: currentUser = $status.viewuser;

    
</script>


<div class="gta-community-hint-container">
    
    <h3>MY WORDS OF WISDOM</h3>
    <div class="gta-wisdom-text-box">
        Legalize Basmati-Reis!
    </div>
    
    
</div>
            

<style>
</style>

<!-- <Skill label="Stamina" value={$users[currentUser].skills.stamina}></Skill> -->