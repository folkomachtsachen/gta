<script>    
</script>


<div class="gta-news-container">
    
    <h3>NEWS</h3>
    <div class="gta-news-image1"></div>
    <div class="gta-news-text">New Release infos available!</div>
    <div class="gta-news-image2"></div>
    <div class="gta-news-text">User map contributions</div>
    
    
</div>
            

<style>
</style>

