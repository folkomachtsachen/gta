<script>

    import Quill from "../quill/Quill.svelte";
    
</script>


<div class="text-editor-container">
    <Quill></Quill>  
</div>


 <style> 
 </style>
