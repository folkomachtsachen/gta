<script>

    export let type = "";
    export let callback = () => { console.log ("Icon18: no callback found:") };

    const getViewBoxString = (w,h) => {
        return ['viewBox="0 0 ', w, ' ', h,'" ','width="', "100", '%"'].join("")
    }

    const getIconType = () => {
       
        if (type === "home") {
            iconNormal = homeNormal;
            iconActive  = homeActive;
        }
    }

    let open        = `<svg xmlns="http://www.w3.org/2000/svg"`; 
    let closeOpen   = `><path fill="`;
    let fill_1      = `rgb(210, 210, 210)`;
    let fill_2      = `rgb(209, 125, 22)`;
    let closefill   =`" `;
    let homePath    = `d="M40.5,20.9v23H7.3V21.2c0-0.7,0.6-1.2,1.2-1.2s1.2,0.6,1.2,1.2v20.3H38V20.9c0-0.7,0.6-1.2,1.2-1.2S40.5,20.2,40.5,20.9zM45,17.5L23.9,3.2L2.8,17.5c-1.3,0.9,0,3,1.4,2.1c0,0,19.7-13.3,19.7-13.3l19.7,13.4C45,20.5,46.4,18.5,45,17.5zM34,6.2h4.2v3.2c0,1.6,2.5,1.6,2.5,0c0,0,0-5.7,0-5.7H34C32.3,3.7,32.3,6.2,34,6.2z"`;
    let close       = `/></svg>`;
   
    let homeNormal = [open, getViewBoxString(48,48), closeOpen, fill_1, closefill, homePath, close].join("");
    let homeActive = [open, getViewBoxString(48,48), closeOpen, fill_2, closefill, homePath, close].join("");
   
    let iconActive;
    let iconNormal;

    getIconType();
    
    $: current = iconNormal;


    const handleClick = () => {
        callback( type );
    }

    const handleMouseEnter = () => {
        current = iconActive;
    }

    const handleMouseLeave = () => {
        // if( !isActive) current = iconNormal;
        current = iconNormal;
    }

</script>



<div 
    class={"icon "} 
    on:click={handleClick}
    on:mouseenter={handleMouseEnter}
    on:mouseleave={handleMouseLeave}>
    
    {@html current}
   
</div>


<style>

    .icon {
        display:inline-block;
        user-select:none;
        cursor:pointer;
    }

</style>
