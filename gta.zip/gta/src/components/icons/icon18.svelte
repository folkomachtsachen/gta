<script>

    export let type = "";
    export let callback = () => { console.log ("Icon18: no callback found:") };

    const getViewBoxString = (w,h) => {
        return ['viewBox="0 0 ', w, ' ', h,'" ','width="', w, 'px"'].join("")
    }

    const getIconType = () => {
       
        if (type === "like") {
            iconNormal = likeNormal;
            iconActive  = likeActive;
        }
        if (type === "arrows") {
            iconNormal = arrowsNormal;
            iconActive  = arrowsActive;
        }
        if (type === "up") {
            iconNormal = upNormal;
            iconActive  = upActive;
        }
        if (type === "bubble") {
            iconNormal = bubbleNormal;
            iconActive = bubbleActive;
        }
    }

    let open        = `<svg xmlns="http://www.w3.org/2000/svg"`; 
    let closeOpen   = `><path fill="`;
    let fill_1      = `rgb(0,0,0)`;
    let fill_2      = `rgb(255,155,12)`;
    let closefill   =`" `;
    let likePath    = `d="M17.2,6.9h-4.7c0.5-1.4,0.9-5.8-1.8-6.1C9.7,0.8,9,1.5,9,1.6C8.9,1.7,8.9,1.8,8.9,1.9C9,2.3,9.1,3.4,9.1,3.8C9,4.7,7.4,6.9,6.9,8C6.6,8.1,6,7.9,5.9,8.5c0,0,0,7.2,0,7.2c0,0.4,0.4,0.5,0.7,0.5c0.1,0,0.5,0.2,0.8,0.5C7.8,16.9,8.7,16.9,9,17h6.7c1.2,0.1,1.8-1.5,1.1-2.4c0.8-0.3,1.1-1.4,0.6-2.1c0.8-0.3,1.2-1.8,0.5-2.5C19.4,9.2,18.5,6.9,17.2,6.9zM16.8,9.4c-0.5,0-0.6,0.8-0.1,0.9c1.1,0.3,0.6,1.5-0.3,1.5c-0.5,0-0.6,0.7-0.2,0.9c0,0,0.5,0.3,0.5,0.7c-0.2,0.8-1.1,0.4-1.3,1c-0.1,0.6,0.7,0.4,0.7,1.2C16.1,16,15.9,16,15.7,16c0,0-6.7,0-6.7,0c-1,0-1.4-0.7-2.1-0.8V8.9c0.3,0,0.6-0.1,0.8-0.4c0.2-0.3,1.9-3.3,1.9-3.3c0-0.1,0.4-0.7,0.4-1.3C10,3.4,9.9,2.5,9.9,2c1-1,2,0.2,2.1,1.5c0.2,2-0.5,3.6-0.5,3.6c-0.1,0.3,0.1,0.6,0.4,0.6l5.2,0C18.1,8,18,9.4,16.8,9.4zM4.2,8H1.6C1.3,8,1,8.3,1,8.6v6.9c0,0.3,0.3,0.6,0.6,0.6h2.6c0.3,0,0.6-0.3,0.6-0.6V8.6C4.8,8.3,4.5,8,4.2,8z M3.9,15.2h-2V8.9h2V15.2z"`;
    let arrowsPath  = `d="M19.2,14L16,16.9c-0.1,0.1-0.2,0.1-0.3,0.1c-0.1,0-0.2-0.1-0.3-0.1c0,0-3.2-2.9-3.2-2.9c-0.5-0.4,0.2-1.2,0.7-0.7l2.3,2.1V4.1c0-1.1-0.9-1.9-1.9-1.9c0,0-4.5,0-4.5,0c-0.7,0-0.7-1,0-1h4.5c1.6,0,2.9,1.3,2.9,2.9v11.2l2.3-2.1c0.2-0.2,0.5-0.2,0.7,0C19.4,13.5,19.4,13.8,19.2,14zM4.8,13.8V2.6l2.3,2.1C7.6,5.2,8.3,4.4,7.8,4c0,0-3.2-2.9-3.2-2.9C4.5,0.9,4.2,0.9,4,1.1L0.8,4C0.3,4.4,1,5.2,1.5,4.7c0,0,2.3-2.1,2.3-2.1v11.2c0,1.6,1.3,2.9,2.9,2.9h4.5v-1H6.7C5.7,15.7,4.8,14.9,4.8,13.8z"`;
    let bubblePath  = `d="M9.5,17.2c-0.3,0-0.5-0.2-0.5-0.5c0,0,0-3,0-3H7.4C3.9,13.7,1,10.9,1,7.4S3.9,1,7.4,1h4.8c6.3,0,8.7,8.3,3.4,11.7c0,0-5.9,4.4-5.9,4.4C9.7,17.1,9.6,17.2,9.5,17.2z M7.4,2c-7.1,0.3-7.1,10.5,0,10.7c0,0,2.1,0,2.1,0c0.3,0,0.5,0.2,0.5,0.5v2.5l5-3.7C19.6,9.1,17.6,2,12.2,2C12.2,2,7.4,2,7.4,2z"`;
    let upPath      = `d="M5.3,6c-0.2-0.2-0.2-0.5,0-0.7l4.1-4.1C9.5,1,9.9,1,10.1,1.2l4.1,4.1c0.5,0.5-0.2,1.2-0.7,0.7l-3.2-3.2v9.1c0,0.3-0.2,0.5-0.5,0.5s-0.5-0.2-0.5-0.5V2.8L6,6C5.8,6.2,5.5,6.2,5.3,6zM17.6,10.5v4c0,0.8-0.7,1.5-1.5,1.5H3.5C2.7,16,2,15.3,2,14.5v-4c0-0.7-1-0.7-1,0v4C1,15.9,2.1,17,3.5,17h12.6c1.4,0,2.5-1.1,2.5-2.5v-4C18.6,9.8,17.6,9.8,17.6,10.5z"`;
    let close       = `/></svg>`;
   

    let likeNormal = [open, getViewBoxString(20,18), closeOpen, fill_1, closefill, likePath, close].join("");
    let likeActive = [open, getViewBoxString(20,18), closeOpen, fill_2, closefill, likePath, close].join("");

    let arrowsNormal = [open, getViewBoxString(20,18), closeOpen, fill_1, closefill, arrowsPath, close].join("");
    let arrowsActive = [open, getViewBoxString(20,18), closeOpen, fill_2, closefill, arrowsPath, close].join("");

    let bubbleNormal = [open, getViewBoxString(20,18), closeOpen, fill_1, closefill, bubblePath, close].join("");
    let bubbleActive = [open, getViewBoxString(20,18), closeOpen, fill_2, closefill, bubblePath, close].join("");

    let upNormal    = [open, getViewBoxString(20,18), closeOpen, fill_1, closefill, upPath, close].join("");
    let upActive    = [open, getViewBoxString(20,18), closeOpen, fill_2, closefill, upPath, close].join("");
   
    let iconActive;
    let iconNormal;

    getIconType();
    
    $: current = iconNormal;


    const handleClick = () => {
        callback( type );
    }

    const handleMouseEnter = () => {
        current = iconActive;
    }

    const handleMouseLeave = () => {
        // if( !isActive) current = iconNormal;
        current = iconNormal;
    }

</script>



<div 
    class={"icon "} 
    on:click={handleClick}
    on:mouseenter={handleMouseEnter}
    on:mouseleave={handleMouseLeave}>
    
    {@html current}
   
</div>


<style>

    .icon {
        display:inline-block;
        user-select:none;
        cursor:pointer;
    }

</style>
