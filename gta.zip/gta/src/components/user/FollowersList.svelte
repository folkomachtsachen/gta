<script>

    import { users } from '../stores/Users.js';
    import { status } from '../stores/Status.js';    
    import Buddy from './Buddy.svelte';

    $: currentUser = $status.viewuser;

    const handleBuddyClicked = (userId) => {
        $status.viewuser = userId;
    }

</script>


<div class="gta-follower-container">
    
    <h3>FOLLOWS</h3>
    {#each $users[currentUser].follows as buddy}
        <Buddy user={$users[buddy]} callback={handleBuddyClicked}></Buddy>
	{/each}

</div>


<style> 
</style>
