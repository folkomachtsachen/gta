<script>

    export let user;
    export let callback;

    const handleClick = () => {
        callback(user.id);
    }

</script>


<div class="gta-follower-round-rect" on:click={handleClick}>
    <div class="gta-follower-round-image" style='background-image:url("{user.imageurl}");'></div>
    <div class="gta-follower-text"> {user.name}</div>
</div>


<style> 
</style>
