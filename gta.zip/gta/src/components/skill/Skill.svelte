<script>

    import { tweened } from "svelte/motion";
    import { cubicOut } from "svelte/easing";
    export let label = "Label";
    export let value = 25;

    const progress = tweened (0, {
        duration: 1000,
        easing: cubicOut,
    });

    progress.set(value)   ; 

</script>


<div class="gta-skill-container">

    <div class="gta-skill-label">
       {label}
    </div>
    <div class="gta-skill-bar" style="width:{$progress}%">
    </div>

</div>
            

<style>
</style>