<script>

    import { users } from '../stores/Users.js';
    import { status } from '../stores/Status.js';   
    import Skill from "./Skill.svelte";

    $: currentUser = $status.viewuser;
    
</script>


<div class="gta-skills-container">
    <h3>SKILLS</h3>
    <Skill label="Stamina" value={$users[currentUser].skills.stamina}></Skill>
    <Skill label="Shooting" value={$users[currentUser].skills.shooting}></Skill>
    <Skill label="Strength" value={$users[currentUser].skills.strength}></Skill>
    <Skill label="Flying" value={$users[currentUser].skills.flying}></Skill>
    <Skill label="Driving" value={$users[currentUser].skills.driving}></Skill>
    <Skill label="Lung Capacity" value={$users[currentUser].skills.lungCapacity}></Skill>
</div>
            

<style>
</style>
