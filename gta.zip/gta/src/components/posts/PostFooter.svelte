<script>

    import { status } from '../stores/Status';
    import Icon18 from '../icons/Icon18.svelte';

    export let likes = 0;

    const clickIcon = (str) => {
    }

    const openEditorDialog = () => {
        $status.dialog = "editor";
    }

</script>


<div class="container">

    <Icon18 type="bubble" callback = {openEditorDialog}></Icon18>
    <Icon18 type="arrows" callback = {clickIcon}></Icon18>
    <Icon18 type="up" callback = {clickIcon}></Icon18>
    <div>
        <Icon18 type="like" callback = {clickIcon}></Icon18>
        <div class="amount-likes">{likes}</div>
    </div>

</div>


<style>

   .container {
       display:grid;
       grid-template-columns: 1fr 1fr 1fr 1fr;
       width: 100%;
       min-height: 24px;
       margin-top: 12px;
   }
   .amount-likes {
        display: inline-block;
        transform: translateY(-2px)
   }
   
</style>