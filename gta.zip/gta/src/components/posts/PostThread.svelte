<script>

    import Post from './Post.svelte';
    
    export let postId;

</script>
    
    
<div class="gta-follower-container">
    
    <div class="gta-all-posts-view"> 

        <Post postId={postId}></Post>

    </div>
    
</div>


<style> 
</style>