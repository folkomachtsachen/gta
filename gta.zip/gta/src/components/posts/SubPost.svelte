<script>

    import { users } from '../stores/Users.js';  
    import { posts } from '../stores/Posts.js'; 
    import { status } from '../stores/Status.js';

    export let postId;

    const clickJumpToUser = () => {
        $status.viewuser = $posts[postId].authorId;
    }
     
    </script>
    
    <div class="gta-sub-post-container">
        <div class="head-grid">
            <div class="gta-post-image-small" 
                 style='background-image:url("{$users[$posts[postId].authorId].imageurl}");'
                 on:click = {clickJumpToUser}
                 ></div>
            <div class="author-date">
                <div class="gta-post-author"
                    on:click = {clickJumpToUser}>
                    {$users[$posts[postId].authorId].name}
                </div>
                <div class="gta-post-date">{$posts[postId].date}</div>
            </div>
        </div>
        <div class="gta-post-body-text">
            {$posts[postId].body}
        </div>
    </div>
        
    
    <style> 

        .head-grid {
            display: grid;
            grid-template-columns: 30px auto;
            width: 100%;
        }

        .author-date {
            display: flex;
            gap: 5px;
        }

    </style>