<script>

    import { users } from '../stores/Users.js';  
    import { posts } from '../stores/Posts.js'; 
    import PostFooter from './PostFooter.svelte';  
    import SubPost from './SubPost.svelte';    
    
    export let postId = "00_0_pseudo"; // placeholder, id comes from parent

    const clickUser = () => {
        // console.log("click user:", $posts[postId].authorId);
    }

</script>
    


<div class="gta-post-container">
   
    <div class="gta-post-image-normal" 
            style='background-image:url("{$users[$posts[postId].authorId].imageurl}");'
            on:click={clickUser}
            >
    </div>
    <div class="gta-post-content">
        
        <div class="head-grid">
            <div class="gta-post-author" 
                    on:click={clickUser}>
                    {$users[$posts[postId].authorId].name}
            </div>
            <div class="gta-post-date">{$posts[postId].date}</div>
        </div>

        <div class="gta-post-body-text">
            {$posts[postId].body}
        </div>

        <PostFooter likes={$posts[postId].likes}></PostFooter>

        {#each $posts[postId].sub as subPost}
            <SubPost postId= {subPost}></SubPost>
        {/each}

    </div>
               
</div>
    
    
<style> 

    .head-grid {
        display:flex;
        gap: 5px;
        width: 100%;
    }

</style>