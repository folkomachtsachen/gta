<script>

    export let callback = () => { console.log ("ButtonOk, no callback found:") };

    const handleClick = () => {
        callback();
    }

</script>


<div class="gta-btn gta-ok-btn" on:click={handleClick}>OK</div>


 <style>
 </style>