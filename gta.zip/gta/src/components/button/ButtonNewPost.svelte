<script>

    export let title = "Follow";
    export let value = false;
    export let callback = () => { console.log ("Button clicked, no callback found:", title, value ) };

    const handleClick = () => {
        callback( title, value );
    }

</script>


<div class="gta-btn gta-new-post-btn" 
    on:click={handleClick}>
    {title}
</div>


 <style>
 </style>