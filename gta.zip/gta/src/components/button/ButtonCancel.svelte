<script>

    export let callback = () => { console.log ("ButtonCancel, no callback found:") };

    const handleClick = () => {
        callback();
    }

</script>


<div class="gta-btn gta-cancel-btn" on:click={handleClick}>Cancel</div>


 <style>
 </style>