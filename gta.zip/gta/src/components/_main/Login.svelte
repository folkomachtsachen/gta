<script>

    import { status } from '../stores/Status.js'; 
    import LoginHeader from "./header/LoginHeader.svelte";
    import LoginForm from "../login/LoginForm.svelte";
   

    const handleLoginSuccess = () => {
        $status.loggedin = true;
    }
    
</script>


<div>
    <LoginHeader></LoginHeader>
    <div style="height:100px;"></div>
    <LoginForm callback={handleLoginSuccess}></LoginForm>
    <div style="height:100px;"></div>
</div>


