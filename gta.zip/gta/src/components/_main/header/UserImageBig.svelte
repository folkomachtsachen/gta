<script>
    
    export let imageurl;
    
</script>


<div class='gta-user-image-big' style='background-image:url("{imageurl}");' >
</div>
      

<style>
</style>