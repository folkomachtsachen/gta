<script>
</script>


<div class="gta-logo-box">
    <div class="gta-logo"></div>
</div>


<style>
</style>


