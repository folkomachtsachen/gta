<script>

    import { users } from '../../stores/Users.js';
    import { status } from '../../stores/Status.js';
    import LogoBoxRight from './LogoBoxRight.svelte';
    import UserImageBig from './UserImageBig.svelte';

</script>


<div class="gta-top-container">
    <div></div>
    
    <div class="gta-top">
        <LogoBoxRight></LogoBoxRight>
        <UserImageBig imageurl={$users[$status.viewuser].imageurl}></UserImageBig> 
    </div> 

    <div></div>    
</div>


<style>
</style>