<script>

    import LogoBox from './LogoBox.svelte';

</script>


<div class="gta-top-container">

    <div>
    </div>
    <div class="gta-top">
        <LogoBox></LogoBox>
    </div> 
    <div></div>  
    
</div>



<style>
</style>