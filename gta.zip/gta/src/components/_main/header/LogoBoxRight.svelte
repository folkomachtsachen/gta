<script>

    import { status } from '../../stores/Status.js';  

     // go back home:
    const clickIcon = () => {
        $status.viewuser = "user_0";
    }

</script>


<div class="gta-logo-box-right">
    <div class="gta-logo" on:click={clickIcon}></div> 
</div>


<style>
</style>


