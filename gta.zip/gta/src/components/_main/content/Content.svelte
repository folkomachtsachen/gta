<script>

    import ColumnLeft from './columnLeft/ColumnLeft.svelte';
    import ColumnCenter from './columnCenter/ColumnCenter.svelte';
    import ColumnRight from './columnRight/ColumnRight.svelte';

</script>


<div class="gta-content-container">
    
    <div></div>
    <div class="gta-content-grid">
        <ColumnLeft></ColumnLeft>
        <ColumnCenter></ColumnCenter>
        <ColumnRight></ColumnRight>
    </div>  
    <div></div>
</div>


<style>
</style>