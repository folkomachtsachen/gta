<script>

    import PostThread from '../../../posts/PostThread.svelte';
    import { postsPerUser } from '../../../stores/PostsPerUser.js';
    import { status } from '../../../stores/Status.js';

    $: currentUser = $status.viewuser;
    
</script>


<div class="gta-column-center">
    
    <div class="gta-columns-top gta-column-center-top"></div>
    <h3>CONVERSATION</h3>

    {#each $postsPerUser[currentUser] as mainPostId}
        <PostThread postId={mainPostId}></PostThread>
    {/each}

</div>


<style>
</style>