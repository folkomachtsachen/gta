<script>

    import { status } from '../../../stores/Status.js';  
    import Skills from "../../../skill/Skills.svelte";
    import Wisdom from "../../../wisdom/Wisdom.svelte";

</script>


<div class="gta-column-left">

    <div class="gta-columns-top gta-column-left-top"></div>
    {#key $status.viewuser}
        <Skills ></Skills>
    {/key}
    {#key $status.viewuser}
        <Wisdom ></Wisdom>
    {/key}
   
</div>


<style>
</style>