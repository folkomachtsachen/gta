<script>

    import FollowersList from '../../../user/FollowersList.svelte';
    import NewsList from '../../../news/NewsList.svelte';

</script>


<div class="gta-column-right">

    <div class="gta-columns-top gta-column-right-top"></div>
    <FollowersList></FollowersList>
    <NewsList></NewsList>

</div>
            


<style>
</style>