<script>
    
    import Header from "./header/Header.svelte";
    import UserHeader from './userHeader/UserHeader.svelte';
    import Content from "./content/Content.svelte";

</script>


<div>

    <Header></Header>
    <UserHeader></UserHeader>
    <Content></Content>
    <div style="height:100px;"></div>
    
</div>


 <style> 
 </style>
