<script>
    
    import { status } from "../../stores/Status";
    import ButtonFollow from "../../button/ButtonFollow.svelte";
    import ButtonNewPost from "../../button/ButtonNewPost.svelte";
    
    export let user;
    
    const openEditorDialog = () => {
        $status.dialog = "editor";
    }

</script>



<div class='containerY'>
    <div>
        <div class="row1">
            <div class="gta-user-info-box-name">{user.name}</div>
        </div> 
        <div class="row2">
            <div>Joined: {user.joined}</div>
            <div>Followers: <span class="bold">{user.followers}</span></div>
            <div>Following: <span class="bold">{user.follows.length}</span></div>
        </div>
    </div>
    <div>
        {#if user.name === "Thunderspatz"}
        <ButtonNewPost title="New Post" callback={openEditorDialog}></ButtonNewPost>
        {:else}
        <ButtonFollow title="Follow"></ButtonFollow>
        {/if}
    </div>
    
</div>



<style>

    .containerY {
        display:grid;
        grid-template-columns: 60% auto;
        padding: 30px 0px;
        width: 100%
    }
    .row1 {
        display:grid;
        padding-left:20px;
    }
    .row2 {
        display:flex;
        gap:30px;
        padding-left:20px;
    }
    .bold {
        font-weight: 800;
        color:black;
    }

</style>