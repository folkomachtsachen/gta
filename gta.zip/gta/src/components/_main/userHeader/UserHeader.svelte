<script>

    import { users } from '../../stores/Users.js';
    import { status } from '../../stores/Status.js';
    import UserInfo from './UserInfo.svelte';

</script>


<div class="gta-user-row-container">

    <div></div>
    <div class="gta-user-row-grid ">
        <div></div>
        <UserInfo user={$users[$status.viewuser]}></UserInfo>
    </div>
    <div></div>
    
</div>


<style>
</style>