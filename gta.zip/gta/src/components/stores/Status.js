import { writable } from 'svelte/store';


export const status = writable({
    
    user: "user_0",
    loggedin: false,
    viewuser:"user_0",
    dialog: "none",

});
