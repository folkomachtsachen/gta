import { writable } from 'svelte/store';


export const postsPerUser = writable({
    
    "user_0": ["00_0_pseudo", "04_1_pseudo", "00_2_pseudo", "00_3_pseudo"],
    "user_1": ["01_0_pseudo", "01_1_pseudo", "01_2_pseudo"],
    "user_2": ["02_0_pseudo", "02_1_pseudo", "02_2_pseudo"],
    "user_3": ["03_0_pseudo", "03_1_pseudo", "03_2_pseudo",  "03_3_pseudo"],
    "user_4": ["04_0_pseudo", "04_1_pseudo"],
    "user_5": ["05_0_pseudo", "05_1_pseudo", "05_2_pseudo"],
    "user_6": ["06_0_pseudo", "06_1_pseudo", "06_2_pseudo"],
    "user_7": ["07_0_pseudo", "07_1_pseudo", "07_2_pseudo", "07_3_pseudo"],
    "user_8": ["08_0_pseudo", "08_1_pseudo", "08_2_pseudo"],
    "user_9": ["09_0_pseudo", "09_1_pseudo", "09_2_pseudo"],
    "user_10": ["10_0_pseudo", "10_1_pseudo", "10_2_pseudo"],
    "user_11": ["11_0_pseudo", "11_1_pseudo"],
    "user_12": ["12_0_pseudo", "12_1_pseudo", "12_2_pseudo"],
    "user_13": ["13_0_pseudo", "13_1_pseudo", "13_2_pseudo"],
    "user_14": ["14_0_pseudo", "14_1_pseudo", "14_2_pseudo", "14_3_pseudo"],
    "user_15": ["15_0_pseudo", "15_1_pseudo", "15_2_pseudo"]
      
});
