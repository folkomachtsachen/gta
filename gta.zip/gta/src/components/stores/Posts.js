import { writable } from 'svelte/store';


export const posts = writable({
    
    "00_0_pseudo": {
        authorId:"user_0",
        body:"My calculations are correct, when this baby hits eighty-eight miles per hour, your gonna see some serious shit.",
        date:"17.02.2022",
        likes: 12,
        sub: ["02_4_pseudo", "01_0_pseudo", "13_2_pseudo"],
    },

    "00_1_pseudo": {
        authorId:"user_0",
        body:"Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus.",
        date:"19.03.2022",
        likes: 44,
        sub: ["03_1_pseudo", "04_0_pseudo", "15_2_pseudo"],
    },

    "00_2_pseudo": {
        authorId:"user_0",
        body:"Ha, what did I tell you, eighty-eight miles per hour. The temporal displacement occurred at exactly 1:20 a.m. and zero seconds. Oh.",
        date:"04.03.2022",
        likes: 3,
        sub: ["05_2_pseudo", "06_0_pseudo", "14_1_pseudo"],
    },

    "00_3_pseudo": {
        authorId:"user_0",
        body:"Aenean commodo ligula eget dolor. Aenean massa.",
        date:"21.06.2022",
        likes: 134,
        sub: ["06_2_pseudo", "05_0_pseudo", "13_1_pseudo"],
    },

    "00_4_pseudo": {
        authorId:"user_0",
        body:"Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. ",
        date:"21.06.2022",
        likes: 87,
        sub: ["01_3_pseudo", "11_0_pseudo", "12_1_pseudo"],
    },


    sep:"--------------------------------------",


    "01_0_pseudo": {
        authorId:"user_1",
        body:"Sed lectus. Donec mollis hendrerit risus. Phasellus nec sem in justo pellentesque facilisis.",
        date:"17.02.2022",
        likes: 17,
        sub: ["00_3_pseudo", "04_2_pseudo", "05_3_pseudo"],
    },

    "01_1_pseudo": {
        authorId:"user_1",
        body:"Phasellus leo dolor, tempus non.",
        date:"19.03.2022",
        likes: 24,
        sub: ["07_1_pseudo", "08_1_pseudo", "15_4_pseudo"],
    },

    "01_2_pseudo": {
        authorId:"user_1",
        body:"Sed aliquam, nisi quis.",
        date:"04.03.2022",
        likes: 8,
        sub: ["07_2_pseudo", "03_3_pseudo", "14_0_pseudo"],
    },

    "01_3_pseudo": {
        authorId:"user_1",
        body:"Vestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus.",
        date:"21.06.2022",
        likes: 11,
        sub: ["03_0_pseudo", "09_0_pseudo", "11_0_pseudo"],
    },

    "01_4_pseudo": {
        authorId:"user_1",
        body:"Libero venenatis!",
        date:"21.06.2022",
        likes: 27,
        sub: ["04_4_pseudo", "03_4_pseudo", "10_1_pseudo"],
    },


    sep:"--------02------------------------------",


    "02_0_pseudo": {
        authorId:"user_2",
        body:"Praesent adipiscing. Phasellus ullamcorper ipsum rutrum nunc. Nunc nonummy metus. Vestibulum volutpat pretium libero.",
        date:"17.02.2022",
        likes: 34,
        sub: ["06_0_pseudo", "07_2_pseudo", "11_4_pseudo"],
    },

    "02_1_pseudo": {
        authorId:"user_2",
        body:"Nunc nec neque. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi.",
        date:"19.03.2022",
        likes: 21,
        sub: ["09_4_pseudo", "08_0_pseudo", "15_3_pseudo"],
    },

    "02_2_pseudo": {
        authorId:"user_2",
        body:"Schedi shonk.",
        date:"04.03.2022",
        likes: 62,
        sub: ["14_2_pseudo", "03_0_pseudo", "00_3_pseudo"],
    },

    "02_3_pseudo": {
        authorId:"user_2",
        body:"Sed cursus turpis vitae tortor. Donec posuere vulputate arcu.",
        date:"21.06.2022",
        likes: 167,
        sub: ["05_2_pseudo", "10_4_pseudo", "06_1_pseudo"],
    },

    "02_4_pseudo": {
        authorId:"user_2",
        body:"Praesent turpis. Aenean posuere, tortor sed cursus feugiat, nunc augue blandit nunc, eu sollicitudin urna dolor sagittis lacus. Donec elit libero, sodales nec, volutpat a, suscipit non, turpis.",
        date:"21.06.2022",
        likes: 73,
        sub: ["00_1_pseudo", "04_0_pseudo", "05_0_pseudo"],
    },


    sep:"-----------03---------------------------",


    "03_0_pseudo": {
        authorId:"user_3",
        body:"Time-circuits on, flux-capacitor fluxing, engine running, alright. No, no no no no, c'mon c'mon.",
        date:"17.02.2022",
        likes: 45,
        sub: ["06_3_pseudo", "02_1_pseudo", "00_3_pseudo"],
    },

    "03_1_pseudo": {
        authorId:"user_3",
        body:"10 minutes oughta do it.",
        date:"19.03.2022",
        likes: 22,
        sub: ["07_4_pseudo", "12_0_pseudo", "13_1_pseudo"],
    },

    "03_2_pseudo": {
        authorId:"user_3",
        body:"Wait a minute, I got all the time I want I got a time machine.",
        date:"04.03.2022",
        likes: 63,
        sub: ["04_1_pseudo", "05_0_pseudo", "14_3_pseudo"],
    },

    "03_3_pseudo": {
        authorId:"user_3",
        body:"Whoa, they really cleaned this place up, looks brand new. Dammit, Doc, why did you have to tear up that letter? If only I had more time.",
        date:"21.06.2022",
        likes: 37,
        sub: ["05_4_pseudo", "07_2_pseudo", "08_4_pseudo"],
    },

    "03_4_pseudo": {
        authorId:"user_3",
        body:"Huh? Oh, you make it sound so easy. I just, I wish I wasn't so scared. ",
        date:"21.06.2022",
        likes: 9,
        sub: ["00_4_pseudo", "03_2_pseudo", "05_0_pseudo"],
    },


    sep:"-----------04---------------------------",


    "04_0_pseudo": {
        authorId:"user_4",
        body:"Time-circuits on, flux-capacitor fluxing, engine running, alright. No, no no no no, c'mon c'mon.",
        date:"17.02.2022",
        likes: 5,
        sub: ["04_0_pseudo", "02_2_pseudo", "14_2_pseudo"],
    },

    "04_1_pseudo": {
        authorId:"user_4",
        body:"10 minutes oughta do it.",
        date:"19.03.2022",
        likes: 52,
        sub: ["03_4_pseudo", "05_0_pseudo", "09_3_pseudo"],
    },

    "04_2_pseudo": {
        authorId:"user_4",
        body:"Wait a minute, I got all the time I want I got a time machine.",
        date:"04.03.2022",
        likes: 39,
        sub: ["05_4_pseudo", "10_1_pseudo", "11_2_pseudo"],
    },

    "04_3_pseudo": {
        authorId:"user_4",
        body:"Whoa, they really cleaned this place up, looks brand new. Dammit, Doc, why did you have to tear up that letter? If only I had more time.",
        date:"21.06.2022",
        likes: 4,
        sub: ["06_5_pseudo", "15_0_pseudo", "11_4_pseudo"],
    },

    "04_4_pseudo": {
        authorId:"user_4",
        body:"Huh? Oh, you make it sound so easy. I just, I wish I wasn't so scared. ",
        date:"21.06.2022",
        likes: 129,
        sub: ["07_1_pseudo", "00_4_pseudo", "02_0_pseudo"],
    },

    sep:"-----------05---------------------------",


    "05_0_pseudo": {
        authorId:"user_5",
        body:"Look at the time, you've got less than 4 minutes, please hurry. Hey, George, buddy, you weren't at school, what have you been doing all day?",
        date:"17.02.2022",
        likes: 74,
        sub: ["00_4_pseudo", "11_0_pseudo", "12_1_pseudo"],
    },

    "05_1_pseudo": {
        authorId:"user_5",
        body:"What about George?",
        date:"19.03.2022",
        likes: 19,
        sub: ["04_4_pseudo", "13_4_pseudo", "01_1_pseudo"],
    },

    "05_2_pseudo": {
        authorId:"user_5",
        body:"Yeah, but I never picked a fight in my entire life. Something that really cooks. ",
        date:"04.03.2022",
        likes: 6,
        sub: ["13_0_pseudo", "09_3_pseudo", "08_4_pseudo"],
    },

    "05_3_pseudo": {
        authorId:"user_5",
        body:"Alright, alright this is an oldie, but uh, it's an oldie where I come from.",
        date:"21.06.2022",
        likes: 245,
        sub: ["07_0_pseudo", "02_3_pseudo", "11_0_pseudo"],
    },

    "05_4_pseudo": {
        authorId:"user_5",
        body:"Alright guys, let's do some blues riff in b, watch me for the changes, and uh, try and keep up, okay.",
        date:"21.06.2022",
        likes: 82,
        sub: ["08_2_pseudo", "09_3_pseudo", "00_2_pseudo"],
    },

    sep:"-----------06---------------------------",


    "06_0_pseudo": {
        authorId:"user_6",
        body:"Hey, hey, keep rolling, keep rolling there. No, no, no, no, this sucker's electrical.",
        date:"17.02.2022",
        likes: 56,
        sub: ["01_0_pseudo", "06_2_pseudo", "01_2_pseudo"],
    },

    "06_1_pseudo": {
        authorId:"user_6",
        body:"How could I have been so careless.",
        date:"19.03.2022",
        likes: 12,
        sub: ["05_4_pseudo", "12_1_pseudo", "11_4_pseudo"],
    },

    "06_2_pseudo": {
        authorId:"user_6",
        body:"One point twenty-one gigawatts. Tom, how am I gonna generate that kind of power, it can't be done, it can't.",
        date:"04.03.2022",
        likes: 31,
        sub: [],
    },

    "06_3_pseudo": {
        authorId:"user_6",
        body:"My equipment, that reminds me, Marty, you better not hook up to the amplifier. There's a slight possibility for overload.",
        date:"21.06.2022",
        likes: 52,
        sub: ["11_3_pseudo", "02_0_pseudo", "00_0_pseudo"],
    },

    "06_4_pseudo": {
        authorId:"user_6",
        body:"Okay, but I don't know what to say. You'll find out in thirty years.",
        date:"21.06.2022",
        likes: 88,
        sub: ["03_0_pseudo", "02_0_pseudo", "12_4_pseudo"],
    },


    sep:"-----------07---------------------------",


    "07_0_pseudo": {
        authorId:"user_7",
        body:"Dammit, Doc, why did you have to tear up that letter? If only I had more time.",
        date:"17.02.2022",
        likes: 26,
        sub: ["15_0_pseudo", "03_4_pseudo", "06_4_pseudo"],
    },

    "07_1_pseudo": {
        authorId:"user_7",
        body:"I got all the time I want I got a time machine, I'll just go back and warn him. 10 minutes oughta do it.",
        date:"19.03.2022",
        likes: 61,
        sub: ["11_2_pseudo", "09_4_pseudo", "01_4_pseudo"],
    },

    "07_2_pseudo": {
        authorId:"user_7",
        body:"Well, it will just happen.",
        date:"04.03.2022",
        likes: 79,
        sub: ["08_0_pseudo", "02_2_pseudo", "15_0_pseudo"],
    },

    "07_3_pseudo": {
        authorId:"user_7",
        body:"That's good advice, Marty. That's for messing up my hair. My god, it's my mother. Put your pants back on. He's a peeping tom. Dad. What Lorraine, what?",
        date:"21.06.2022",
        likes: 38,
        sub: ["06_0_pseudo", "02_0_pseudo", "14_3_pseudo"],
    },

    "07_4_pseudo": {
        authorId:"user_7",
        body:"Calm down, Marty, I didn't disintegrate anything.",
        date:"21.06.2022",
        likes: 82,
        sub: ["08_0_pseudo", "05_2_pseudo", "11_2_pseudo"],
    },


    sep:"-----------08---------------------------",


    "08_0_pseudo": {
        authorId:"user_8",
        body:"Shit. Look, George, I'm telling you George, if you do not ask Lorraine to that dance, I'm gonna regret it for the rest of my life. ",
        date:"17.02.2022",
        likes: 7,
        sub: ["10_3_pseudo", "12_1_pseudo", "05_0_pseudo"],
    },

    "08_1_pseudo": {
        authorId:"user_8",
        body:"That's a Florence Nightingale effect.",
        date:"19.03.2022",
        likes: 51,
        sub: ["02_1_pseudo", "08_3_pseudo", "11_1_pseudo"],
    },

    "08_2_pseudo": {
        authorId:"user_8",
        body:"It happens in hospitals when nurses fall in love with their patients. Go to it, kid.",
        date:"04.03.2022",
        likes: 75,
        sub: ["01_3_pseudo", "07_4_pseudo", "13_0_pseudo"],
    },

    "08_3_pseudo": {
        authorId:"user_8",
        body:"Okay, alright, Saturday is good, Saturday's good, I could spend a week in 1955.",
        date:"21.06.2022",
        likes: 59,
        sub: ["13_3_pseudo", "00_4_pseudo", "08_2_pseudo"],
    },

    "08_4_pseudo": {
        authorId:"user_8",
        body:"I could hang out, you could show me around.",
        date:"21.06.2022",
        likes: 16,
        sub: ["10_3_pseudo", "01_2_pseudo", "04_2_pseudo"],
    },


    sep:"-----------09---------------------------",


    "09_0_pseudo": {
        authorId:"user_10",
        body:"Alright, okay listen, keep your pants on, she's over in the cafe. God, how do you do this? What made you change your mind",
        date:"17.02.2022",
        likes: 2,
        sub: ["11_4_pseudo", "04_4_pseudo", "01_3_pseudo"],
    },

    "09_1_pseudo": {
        authorId:"user_9",
        body:"Now which one was it, Greg or Craig?",
        date:"19.03.2022",
        likes: 32,
        sub: ["15_1_pseudo", "00_1_pseudo", "05_4_pseudo"],
    },

    "09_2_pseudo": {
        authorId:"user_9",
        body:"Unfortunately no, it requires something with a little more kick, plutonium.",
        date:"04.03.2022",
        likes: 53,
        sub: ["11_1_pseudo", "01_3_pseudo", "06_3_pseudo"],
    },

    "09_3_pseudo": {
        authorId:"user_9",
        body:"Right. Lorraine, have you ever, uh, been in a situation where you know you had to act a certain way but when you got there, you didn't know if you could go through with it? ",
        date:"21.06.2022",
        likes: 5,
        sub: ["14_0_pseudo", "13_1_pseudo", "04_1_pseudo"],
    },

    "09_4_pseudo": {
        authorId:"user_9",
        body:"My god, do you know what this means? It means that this damn thing doesn't work at all. ",
        date:"21.06.2022",
        likes: 13,
        sub: ["15_0_pseudo", "03_0_pseudo", "09_1_pseudo"],
    },

    sep:"-----------10---------------------------",


    "10_0_pseudo": {
        authorId:"user_10",
        body:"Uncle Jailbird Joey? ",
        date:"17.02.2022",
        likes: 51,
        sub: ["11_0_pseudo", "00_3_pseudo", "07_1_pseudo"],
    },

    "10_1_pseudo": {
        authorId:"user_10",
        body:"Excuse me. Lorraine. I can't play. One point twenty-one gigawatts.",
        date:"19.03.2022",
        likes: 48,
        sub: ["06_0_pseudo", "01_4_pseudo", "05_4_pseudo"],
    },

    "10_2_pseudo": {
        authorId:"user_10",
        body:"No, it was The Enchantment Under The Sea Dance. Our first date. It was the night of that terrible thunderstorm, remember George? ",
        date:"04.03.2022",
        likes: 15,
        sub: ["14_1_pseudo", "03_3_pseudo", "06_0_pseudo"],
    },

    "10_3_pseudo": {
        authorId:"user_10",
        body:"Alright, punk, now- You know what I do in those situations? What did she say?",
        date:"21.06.2022",
        likes: 8,
        sub: ["10_4_pseudo", "00_1_pseudo", "04_3_pseudo"],
    },

    "10_4_pseudo": {
        authorId:"user_10",
        body:"It's your mom, she's tracked you down. Quick, let's cover the time machine.",
        date:"21.06.2022",
        likes: 34,
        sub: ["13_0_pseudo", "04_0_pseudo", "07_0_pseudo"],
    },


    sep:"-----------11---------------------------",


    "11_0_pseudo": {
        authorId:"user_11",
        body:"Uncle Jailbird Joey? ",
        date:"17.02.2022",
        likes: 72,
        sub: ["07_0_pseudo", "04_4_pseudo", "02_2_pseudo"],
    },

    "11_1_pseudo": {
        authorId:"user_11",
        body:"Excuse me. Lorraine. I can't play. One point twenty-one gigawatts.",
        date:"19.03.2022",
        likes: 82,
        sub: ["05_1_pseudo", "06_4_pseudo", "01_2_pseudo"],
    },

    "11_2_pseudo": {
        authorId:"user_11",
        body:"No, it was The Enchantment Under The Sea Dance. Our first date. It was the night of that terrible thunderstorm, remember George? ",
        date:"04.03.2022",
        likes: 13,
        sub: ["12_2_pseudo", "09_3_pseudo", "03_5_pseudo"],
    },

    "11_3_pseudo": {
        authorId:"user_11",
        body:"Alright, punk, now- You know what I do in those situations? What did she say?",
        date:"21.06.2022",
        likes: 26,
        sub: ["08_4_pseudo", "01_3_pseudo", "06_1_pseudo"],
    },

    "11_4_pseudo": {
        authorId:"user_11",
        body:"It's your mom, she's tracked you down. Quick, let's cover the time machine.",
        date:"21.06.2022",
        likes: 4,
        sub: ["00_3_pseudo", "02_1_pseudo", "03_4_pseudo"],
    },

    sep:"-----------12---------------------------",

    "12_0_pseudo": {
        authorId:"user_12",
        body:"Let's see if you bastards can do ninety. You know, Doc, you left your equipment on all week.",
        date:"17.02.2022",
        likes: 143,
        sub: ["09_2_pseudo", "08_0_pseudo", "15_2_pseudo"],
    },

    "12_1_pseudo": {
        authorId:"user_12",
        body:"What on Earth is that thing I'm wearing? Whoa, wait, Doc. Yeah. C'mon, more, dammit. Jeez. Holy shit. ",
        date:"19.03.2022",
        likes: 84,
        sub: ["14_3_pseudo", "02_0_pseudo", "13_1_pseudo"],
    },

    "12_2_pseudo": {
        authorId:"user_12",
        body:"Thank god I still got my hair.",
        date:"04.03.2022",
        likes: 93,
        sub: ["07_1_pseudo", "11_0_pseudo", "10_0_pseudo"],
    },

    "12_3_pseudo": {
        authorId:"user_12",
        body:"Who's are these? You do? Yeah. Doc. Calvin, why do you keep calling me Calvin?",
        date:"21.06.2022",
        likes: 17,
        sub: ["03_3_pseudo", "08_0_pseudo", "10_2_pseudo"],
    },

    "12_4_pseudo": {
        authorId:"user_12",
        body:"He's a peeping tom. Dad. I'll be at my grandma's. Here, let me give you the number. Bye.",
        date:"21.06.2022",
        likes: 33,
        sub: ["09_4_pseudo", "01_3_pseudo", "00_2_pseudo"],
    },


    sep:"-----------13---------------------------",


    "13_0_pseudo": {
        authorId:"user_13",
        body:"Erased from existence. Stand tall, boy, have some respect for yourself. Don't you know that if you let people walk all over you know, they'll be walking all over you for the rest of your life? ",
        date:"17.02.2022",
        likes: 48,
        sub: ["05_3_pseudo", "06_0_pseudo", "02_4_pseudo"],
    },

    "13_1_pseudo": {
        authorId:"user_13",
        body:"Listen to me, do you think I'm gonna spend the rest of my life in this slop house? Yeah I know, If you put your mind to it you could accomplish anything. ",
        date:"19.03.2022",
        likes: 3,
        sub: ["01_3_pseudo", "08_1_pseudo", "13_1_pseudo"],
    },

    "13_2_pseudo": {
        authorId:"user_13",
        body:"No, it was The Enchantment Under The Sea Dance.",
        date:"04.03.2022",
        likes: 8,
        sub: ["00_1_pseudo", "06_1_pseudo", "05_0_pseudo"],
    },

    "13_3_pseudo": {
        authorId:"user_13",
        body:"We all make mistakes in life, children Just finishing up the second coat now. Who's are these? Next, please.",
        date:"21.06.2022",
        likes: 172,
        sub: ["07_2_pseudo", "04_3_pseudo", "08_3_pseudo"],
    },

    "13_4_pseudo": {
        authorId:"user_13",
        body:"Okay, so now, you come up, you punch me in the stomach, I'm out for the count, right?",
        date:"21.06.2022",
        likes: 78,
        sub: ["11_3_pseudo", "10_2_pseudo", "03_2_pseudo"],
    },


    sep:"-----------14---------------------------",


    "14_0_pseudo": {
        authorId:"user_14",
        body:"Calvin, why do you keep calling me Calvin? Well, I figured, what the hell.",
        date:"17.02.2022",
        likes: 29,
        sub: ["03_0_pseudo", "04_0_pseudo", "13_4_pseudo"],
    },

    "14_1_pseudo": {
        authorId:"user_14",
        body:"I'll get it back to you, alright? Unroll their fire.",
        date:"19.03.2022",
        likes: 30,
        sub: ["10_0_pseudo", "02_4_pseudo", "00_4_pseudo"],
    },

    "14_2_pseudo": {
        authorId:"user_14",
        body:"Things have certainly changed around here.",
        date:"04.03.2022",
        likes: 86,
        sub: ["09_0_pseudo", "03_2_pseudo", "01_3_pseudo"],
    },

    "14_3_pseudo": {
        authorId:"user_14",
        body:"I remember when this was all farmland as far as the eye could see. Old man Peabody, owned all of this.",
        date:"21.06.2022",
        likes: 44,
        sub: ["07_2_pseudo", "04_1_pseudo", "09_2_pseudo"],
    },

    "14_4_pseudo": {
        authorId:"user_14",
        body:"He had this crazy idea about breeding pine trees. What's with the life preserver? Hello. What? How's your head?",
        date:"21.06.2022",
        likes: 13,
        sub: ["15_0_pseudo", "06_4_pseudo", "01_1_pseudo"],
    },

    sep:"-----------15---------------------------",


    "15_0_pseudo": {
        authorId:"user_15",
        body:"There's that word again, heavy. Why are things so heavy in the future. Is there a problem with the Earth's gravitational pull?",
        date:"17.02.2022",
        likes: 10,
        sub: ["00_2_pseudo", "11_1_pseudo", "03_0_pseudo"],
    },

    "15_1_pseudo": {
        authorId:"user_15",
        body:"I think we need a rematch.",
        date:"19.03.2022",
        likes: 20,
        sub: ["04_0_pseudo", "07_4_pseudo", "10_2_pseudo"],
    },

    "15_2_pseudo": {
        authorId:"user_15",
        body:"I don't wanna see you in here again. You too. Wow, ah Red, you look great. Everything looks great. 1:24, I still got time. Oh my god.",
        date:"04.03.2022",
        likes: 49,
        sub: ["08_2_pseudo", "01_4_pseudo", "02_2_pseudo"],
    },

    "15_3_pseudo": {
        authorId:"user_15",
        body:"I'm writing this down, this is good stuff. It's uh, the other end of town, a block past Maple. What do you mean you've seen this, it's brand new. Bet your ass it works. No, bastards.",
        date:"21.06.2022",
        likes: 32,
        sub: ["11_0_pseudo", "14_1_pseudo", "03_4_pseudo"],
    },

    "15_4_pseudo": {
        authorId:"user_15",
        body:"Yeah, but you're uh, you're so, you're so thin. Flux capacitor. Well, now we gotta sneak this back into my laboratory, we've gotta get you home.",
        date:"21.06.2022",
        likes: 51,
        sub: ["05_4_pseudo", "06_0_pseudo", "07_1_pseudo"],
    },


});
