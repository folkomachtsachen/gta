import { writable } from 'svelte/store';



export const users = writable({
    
    user_0 : {
        id:"user_0",
        name:"Thunderspatz",
        imageurl: "/img/avatars/bird.jpg",
        skills: {
            stamina: 12,
            shooting: 66,
            strength: 89,
            flying: 45,
            driving: 34,
            lungCapacity:21,
        },
        follows: ["user_15", "user_3", "user_6", "user_8", "user_11"],
        followers: 8,
        joined: "12.12.2019",
        wisdom: "Ein Router, der nicht booten tut, routet nicht mal halb so gut."
    },

    user_1 : {
        id:"user_1",
        name:"CannotBelieve",
        imageurl: "/img/avatars/james.jpg",
        skills: {
            stamina: 34,
            shooting: 78,
            strength: 43,
            flying: 12,
            driving: 45,
            lungCapacity:87,
        },
        follows: ["user_14", "user_0", "user_4"],
        followers: 6,
        joined: "04.09.2021",
        wisdom: "Legalize Basmati-Reis!"
    }, 

    user_2 : {
        id:"user_2",
        name:"Rumpelstolz",
        imageurl: "/img/avatars/ape.jpg",
        skills: {
            stamina: 24,
            shooting: 48,
            strength: 88,
            flying: 15,
            driving: 25,
            lungCapacity:72,
        },
        follows: ["user_3", "user_10", "user_5", "user_6", "user_13", "user_9"],
        followers: 15,
        joined: "01.10.2020",
        wisdom: "Ein Problem ist halb gelöst, wenn es klar formuliert ist."
    }, 

    user_3 : {
        id:"user_3",
        name:"Langhaarigerbombenleger",
        imageurl: "/img/avatars/bomb.jpg",
        skills: {
            stamina: 67,
            shooting: 23,
            strength: 34,
            flying: 67,
            driving: 96,
            lungCapacity:3,
        },
        follows: ["user_0", "user_4", "user_5", "user_12"],
        followers: 4,
        joined: "05.02.2021",
        wisdom: "Wenn jemand zu dir sagt: „Das geht nicht”, dann denke daran, es sind seine Grenzen, nicht deine."
    },

    user_4 : {
        id:"user_4",
        name:"Angryman",
        imageurl: "/img/avatars/danny.jpg",
        skills: {
            stamina: 32,
            shooting: 44,
            strength: 64,
            flying: 17,
            driving: 47,
            lungCapacity:67,
        },
        follows: ["user_12", "user_3", "user_0","user_1"],
        followers: 4,
        joined: "03.01.2021",
        wisdom: "Trenne den Müll, bevor er wegläuft."
    }, 

    user_5 : {
        id:"user_5",
        name:"butterbean",
        imageurl: "/img/avatars/eric.jpg",
        skills: {
            stamina: 2,
            shooting: 14,
            strength: 99,
            flying: 10,
            driving: 42,
            lungCapacity:94,
        },
        follows: ["user_11", "user_7", "user_1", "user_0"],
        followers: 4,
        joined: "01.09.2018",
        wisdom: "Wer war das???"
    }, 

    user_6 : {
        id:"user_6",
        name:"derSchussel",
        imageurl: "/img/avatars/goofy.jpg",
        skills: {
            stamina: 22,
            shooting: 12,
            strength: 5,
            flying: 56,
            driving: 22,
            lungCapacity:84,
        },
        follows: ["user_0", "user_1", "user_2", "user_10", "user_15", "user_14"],
        followers: 4,
        joined: "03.12.2019",
        wisdom: "Opium haut Opi um."
    }, 

    user_7 : {
        id:"user_7",
        name:"KnallhartApfelmus",
        imageurl: "/img/avatars/gta_char1.jpg",
        skills: {
            stamina: 3,
            shooting: 81,
            strength: 78,
            flying: 36,
            driving: 94,
            lungCapacity:54,
        },
        follows: ["user_15", "user_2", "user_0"],
        followers: 4,
        joined: "08.04.2019",
        wisdom: "Wo im Weltall Oben und Unten ist, bestimmt die älteste anwesende Dame."
    }, 

    user_8 : {
        id:"user_8",
        name:"Krawallnudel",
        imageurl: "/img/avatars/gun_girl.jpg",
        skills: {
            stamina: 67,
            shooting: 88,
            strength: 68,
            flying: 96,
            driving: 56,
            lungCapacity:64,
        },
        follows: ["user_15", "user_9", "user_0", "user_4"],
        followers: 4,
        joined: "05.07.2021",
        wisdom: "You are so Beautyfluid."
    }, 

    user_9 : {
        id:"user_9",
        name:"Horst",
        imageurl: "/img/avatars/illustrated.jpg",
        skills: {
            stamina: 27,
            shooting: 48,
            strength: 28,
            flying: 16,
            driving: 66,
            lungCapacity:34,
        },
        follows: ["user_4", "user_6"],
        followers: 4,
        joined: "03.07.2017",
        wisdom: "Dieses Salat-Dressing stammt aus dem Baumarkt."
    }, 

    user_10 : {
        id:"user_10",
        name:"MissMut",
        imageurl: "/img/avatars/marple.jpg",
        skills: {
            stamina: 47,
            shooting: 43,
            strength: 48,
            flying: 48,
            driving: 46,
            lungCapacity:54,
        },
        follows: ["user_0", "user_11", "user_12", "user_14", "user_15"],
        followers: 65,
        joined: "07.11.2018",
        wisdom: "Ist das eine Name oder ein Zustand?."
    }, 

    user_11 : {
        id:"user_11",
        name:"OmarKommt",
        imageurl: "/img/avatars/omar.jpg",
        skills: {
            stamina: 67,
            shooting: 97,
            strength: 68,
            flying: 28,
            driving: 66,
            lungCapacity:44,
        },
        follows: ["user_6", "user_5", "user_2", "user_13"],
        followers: 23,
        joined: "23.02.2019",
        wisdom: "Wadenwickel oder orthodoxer Kopfschmuck?"
    }, 
    
    user_12 : {
        id:"user_12",
        name:"DerDurchblick",
        imageurl: "/img/avatars/pillhuhn.jpg",
        skills: {
            stamina: 62,
            shooting: 37,
            strength: 21,
            flying: 98,
            driving: 7,
            lungCapacity:78,
        },
        follows: ["user_13", "user_10", "user_8", "user_0", "user_3", "user_15", "user_7"],
        followers: 21,
        joined: "17.06.2020",
        wisdom: "Wer trat wem wohin, als wer an was dachte?"
    }, 

    user_13 : {
        id:"user_13",
        name:"BesserBass",
        imageurl: "/img/avatars/primus.jpg",
        skills: {
            stamina: 22,
            shooting: 29,
            strength: 44,
            flying: 45,
            driving: 47,
            lungCapacity:28,
        },
        follows: ["user_10", "user_11", "user_12"],
        followers: 7,
        joined: "12.04.2020",
        wisdom: "Labskaus wird unter Strafe gestellt."
    }, 

    user_14 : {
        id:"user_14",
        name:"Vollautomat",
        imageurl: "/img/avatars/replicant.jpg",
        skills: {
            stamina: 34,
            shooting: 59,
            strength: 24,
            flying: 75,
            driving: 87,
            lungCapacity:18,
        },
        follows: ["user_0", "user_1", "user_15", "user_6", "user_10"],
        followers: 2,
        joined: "06.04.2021",
        wisdom: "Erdnuss, Haselnuss, Tetanus"
    }, 

    user_15 : {
        id:"user_15",
        name:"Randfigur",
        imageurl: "/img/avatars/steven.jpg",
        skills: {
            stamina: 34,
            shooting: 29,
            strength: 74,
            flying: 55,
            driving: 22,
            lungCapacity:78,
        },
        follows: ["user_11", "user_0", "user_1", "user_4", "user_7"],
        followers: 43,
        joined: "03.09.2020",
        wisdom: "Gugelhupf ist eine erfolgreiche Suchanfrage."
    }, 
    
    
});
