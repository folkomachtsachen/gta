<script>

    import { onMount } from 'svelte';
    import { status } from '../stores/Status.js'
    import Quill from 'quill';
    import ButtonOk from "../button/ButtonOk.svelte"; 
    import ButtonCancel from "../button/ButtonCancel.svelte"; 
   
    let quillEditor;
    let count = 0;
	$: charCount = Math.max(0, count -1);
    

    const triggerRender = () => {
        count = quillEditor.getText().length;
    }

    const handleQuillContentChange = (e) => {
        console.log(e);
    }

    const handleOk = () => {
        $status.dialog = "none";
    }

    const handleCancel = () => {
        $status.dialog = "none";
    }
  
    onMount(  () => {
        
        let container = document.getElementById('editor');
        quillEditor = new Quill(container, {
        modules: {
            toolbar: [
            ["bold", "italic", "underline"]
        ]
        },
        placeholder: "Type something...",
        theme: "snow"
        });

        quillEditor.on('text-change', function(delta, oldDelta, source) {

                if (source == 'api') {
                } 
                else if (source == 'user') {
                    triggerRender();
                }
        });
	});

</script>


<div class="quill-container" style="height:160px;">
    <div
        id="editor"   
        class="editor" 
        style="height:160px;" 
        >
    </div>
    <div class="editor-footer-grid">
        <div>
            <div class="editor-char-count">Chars: {charCount} <span>(max. 256)</span></div>
            {#if charCount > 256}
                <div class="warning">Max. 256 chars allowed!</div>
            {/if}
        </div>
        
        <div class="editor-buttons">
            <ButtonCancel callback= {handleCancel}></ButtonCancel>
            <ButtonOk callback= {handleOk}></ButtonOk>
        </div>
    </div>
    
</div>


<style>

    .quill-container {
        grid-template-rows: 1fr;
        width: 100%;
    }
    .editor {
        background-color: rgb(255, 255, 255);
        width: 100%;
    }

    .editor-footer-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }
    .editor-buttons {
        display: flex;
        align-items: flex-end;
        gap: 20px;
        padding-top: 20px;
    }
    .warning {
        color:rgb(185, 27, 27);
    }
   
</style>

