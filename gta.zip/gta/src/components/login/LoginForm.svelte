<script>

    // ref to callback function, set in parent component:
    export let callback = () => { console.log ("Login form: no callback set.") };

    // refs to dom elements:
    let inputUsername;
    let inputPassword;

    // reactive vars, trigger rerender when changed:
    $: showWarningUsername = false;
    $: showWarningPassword = false;


    const checkValues = () => {
        showWarningUsername = (inputUsername.value.length <= 0);
        showWarningPassword = (inputPassword.value.length <= 0);
        if (!showWarningUsername && !showWarningPassword) return true;
        return false;
    }

    const hideWarnings = () => {
        showWarningUsername = false;
        showWarningPassword = false;
    }

    const handleInputChange = (e) => {
        hideWarnings();
    }

    const handleClick = () => {
        if (checkValues()) callback();
    }

</script>


<div class="gta-login-form-container">

    <div class="gta-login-form-headline"><span class="welcome">Welcome,</span> chosen one!</div>
    <div class="gta-login-form">

        <form>
            <label for="username">User name:</label>
            {#if showWarningUsername}
                <span class="warning">User name missing or wrong!</span>
            {/if}
            <br>
            <input class="input" type="text" id="username" name="username" 
                bind:this={inputUsername} 
                on:change={handleInputChange}>
            <br>
            <label for="pword">Password:</label>
            {#if showWarningPassword}
                <span class="warning">Password missing or wrong!</span>
            {/if}
            <br>
            <input class="input" type="password" id="pword" name="pword" 
                bind:this={inputPassword} 
                on:change={handleInputChange}>
            <br>
        </form>

        <div class="gta-login-button" on:click={handleClick}>Login</div>
    </div>
    
    <div class="lost">Lost password?</div>
</div>


<style>

    .input {
        width: 100%;
        padding: 8px;
        font-size: 14px;
        color:black;
        margin-bottom:20px;
    }
    .lost {
        padding: 16px;
        text-align: center;
    }
    .welcome {
        color:black;
    }
    .warning {
        color: rgb(187, 19, 19);
        font-size: 14px;
        font-weight: 700;
    }

</style>