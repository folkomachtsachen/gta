import GTA from './GTA.svelte';

const app = new GTA({
	target: document.body,
	props: {
		
	}
});

export default app;